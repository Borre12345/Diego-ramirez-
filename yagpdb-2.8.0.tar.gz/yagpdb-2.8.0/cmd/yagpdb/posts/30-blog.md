    {
        "author": "jonas747",
        "date": "19th Jan 2018",
        "title": "Status Update"
    }

It's been a while since last update so i thought i would do a status update here and explain why there hasn't been any updates in a while.

I have done various projects related to discord bots the last months even though there hasn't been any pushed updates to YAGPDB, thats mostly been experiments and various other things. I was also taking a break from this project for a while.

As for whats gonna be in the next updates:
 - first i wanna get my new gateway code working, this is not needed but i still wanna do it cause i feel like it, and it may fix the bot getting stuck in voice channels as a side effect.
 - then a smaller update with some bugfixes and tweaks
 - then update the youtube feed to be fast
 - then I'm gonna finish up revamping the command system

After all this i will start on additions and new features again.

### Other things:

 - KingCobra#8803 made a complete video tutorial on how to use the bot](https://youtu.be/zG8PekpD-kk)
 - The bot is now nearing 9k servers!
 - I changed host to a cheaper one, they also experienced a couple networking issues right after i switched which may either be incompetence on their part or bad luck on my part, wether i will switch to another depends on wether the issues persist or not

### Bot lists:

Helping out here helps me getting feedback and making the bot more known

 - [Rate & Write a review on botlist.co](https://botlist.co/bots/yagpdb)
 - [Vote for the bot on discordbots.org](https://discordbots.org/bot/204255221017214977)

### Donations

Switching host reduced costs by quite a bit so I'm not in any dire need of donations anymore but you can still donate to help out the costs and maybe pay for my time a little, check the sidebar for more info.
