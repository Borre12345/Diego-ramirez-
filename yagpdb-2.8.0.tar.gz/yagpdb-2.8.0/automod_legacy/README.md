# Automod

Automod provides some auto moderation features.

Features:

 - Ban websites
 - Ban words
 - Spam detection
 - Ban invite links
 - Mention spam detection
