    {
        "author": "jonas747",
        "date": "21th Jul 2017",
        "title": "One Year!"
    }

It's around one year since i started the development of YAGPDB and it's been neat. I decided to make a survey to give you the ability to leave some feedback!

[Take survery](https://docs.google.com/forms/d/e/1FAIpQLSf6BYGCJBC05bYH4e7s3YARDbm1Xfr4or2ll5anwXjMkWQjog/viewform?usp=sf_link)
