    {
        "author": "jonas747",
        "date": "11th Aug 2016",
        "title": "Version 0.9"
    }

 - Improved all commands that relied on the message history (pastebin, clean, report) to not be limited by message cache
 - Added aylien plugin, currently the only command for it is the sentiment command, see help for more info
