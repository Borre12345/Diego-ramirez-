#common/configstore

Provides 2 backend storages (redis/postgres) and the ability to have custom ones.

Wraps everything around a cache.
