    {
        "author": "jonas747",
        "date": "9th Aug 2016",
        "title": "Version 0.8"
    }

Version 0.8 is released today with some improved backend changes and the reputation system! The reputation system basically lets you give a person 1 rep every now and then if they were helpfull or something like that. You can find it in the control panel under "Fun"