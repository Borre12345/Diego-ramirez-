    {
        "author": "jonas747",
        "date": "15th Aug 2016",
        "title": "Version 0.10"
    }

 - Fixed everything that depended on message history (clean, pastebin uploads etc...)
 - Changed to hastebin from pastebin, because i went above the limit
 - Rewrote the command system
 - cleanups behind the scenes
